#include<stdio.h>
#include<stdbool.h>
#include<stdlib.h>
#include<time.h>

enum { Out, Hit, Double, Triple, HR, BB };

int SK08() {

	int bat;
	int batSK;

	bat = rand() % 5003;
	if (bat >= 0 && bat < 2886) {
		batSK = 0;
	}
	else if (bat >= 2886 && bat < 4108) {
		batSK = 1;
	}
	else if (bat >= 4108 && bat < 4323) {
		batSK = 2;
	}
	else if (bat >= 4323 && bat < 4346) {
		batSK = 3;
	}
	else if (bat >= 4346 && bat < 4435) {
		batSK = 4;
	}
	else if (bat >= 4435 && bat < 5003) {
		batSK = 5;
	}
	return batSK;
}

int �Ե�08() {

	int bat;
	int bat�Ե�;

	bat = rand() % 4890;
	if (bat >= 0 && bat < 2842) {
		bat�Ե� = 0;
	}
	else if (bat >= 2842 && bat < 4042) {
		bat�Ե� = 1;
	}
	else if (bat >= 4042 && bat < 4241) {
		bat�Ե� = 2;
	}
	else if (bat >= 4241 && bat < 4263) {
		bat�Ե� = 3;
	}
	else if (bat >= 4263 && bat < 4356) {
		bat�Ե� = 4;
	}
	else if (bat >= 4356 && bat < 4890) {
		bat�Ե� = 5;
	}
	return bat�Ե�;
}

int cmp(bool* base,bool* base1) {
	int a;
	a = memcmp(base, base1, sizeof(base));
	return a;
}

void basecpy(bool* base, bool* base1)
{
	bool tmp = 0;
	int i;
	for (i = 0; i < 4; i++) {
		tmp = base1[i];
		base[i] = tmp;
	}
}

main()
{
	int outcount;
	int batter;
	int bat;
	int scoreboard[2][10];
	int score = 0;
	int total1 = 0;
	int total2 = 0;
	int win1 = 0;
	int win2 = 0;
	int lose1 = 0;
	int lose2 = 0;
	int draw = 0;
	bool base[4];
	bool base_0[4] = { 0, 0, 0, 0 }; //���� �뺣�̽�
	bool base_1[4] = { 0, 1, 0, 0 }; //���� 1��
	bool base_2[4] = { 0, 0, 1, 0 }; //���� 2��
	bool base_3[4] = { 0, 0, 0, 1 }; //���� 3��
	bool base_12[4] = { 0, 1, 1, 0 }; //���� 1,2��
	bool base_13[4] = { 0, 1, 0, 1 }; //���� 1,3��
	bool base_23[4] = { 0, 0, 1, 1 }; //���� 2,3��
	bool base_f[4] = { 0, 1, 1, 1 }; //���� ����

	for (int i = 0; i < 2; i++) {
		for (int j = 0; j < 10; j++) {
			scoreboard[i][j] = 0;
		}
	}

	srand(time(NULL));
	outcount = 0;
	for (int g = 1; g < 18; g++) {
		score = 0;
		total1 = 0;
		total2 = 0;

		for (int i = 0; i < 2; i++) {
			for (int j = 0; j < 10; j++) {
				scoreboard[i][j] = 0;
			}
		}
		printf("Game %d : SCORE BOARD\n\n", g);

		for (int i = 0; i < 9; i++) {
			outcount = 0;
			base[0] = 0;
			base[1] = 0;
			base[2] = 0;
			base[3] = 0;
			batter = 0;

			while (outcount < 3) {
				batter = SK08();
								if (cmp(base,base_0) == 0) {
					switch (batter) {
					case Out:
						outcount = outcount++;
						break;

					case Hit:
						basecpy(base, base_1);
						break;

					case Double:
						basecpy(base, base_2);
						break;

					case Triple:
						basecpy(base, base_3);
						break;

					case HR:
						score++;
						break;

					case BB:
						basecpy(base, base_1);
					}
				}
				else if (cmp(base, base_1) == 0) {
					switch (batter) {
					case Out:
						outcount = outcount++;
						break;

					case Hit:
						basecpy(base, base_12);
						break;

					case Double:
						basecpy(base, base_23);
						break;

					case Triple:
						basecpy(base, base_3);
						score++;
						break;

					case HR:
						score = score + 2;
						break;

					case BB:
						basecpy(base, base_12);
					}
				}				
				else if (cmp(base, base_2) == 0) {
					switch (batter) {
					case Out:
						outcount = outcount++;
						break;

					case Hit:
						basecpy(base, base_13);
						break;

					case Double:
						basecpy(base, base_2);
						score++;
						break;

					case Triple:
						basecpy(base, base_2);
						score++;
						break;

					case HR:
						score = score + 2;
						break;

					case BB:
						basecpy(base, base_12);
					}
				}
				else if (cmp(base, base_3) == 0) {
					switch (batter) {
					case Out:
						outcount = outcount++;
						break;

					case Hit:
						basecpy(base, base_1);
						score++;
						break;

					case Double:
						basecpy(base, base_2);
						score++;
						break;

					case Triple:
						basecpy(base, base_3);
						score++;
						break;

					case HR:
						score = score + 2;
						break;

					case BB:
						basecpy(base, base_13);
					}
				}
				else if (cmp(base, base_12) == 0) {
					switch (batter) {
					case Out:
						outcount = outcount++;
						break;

					case Hit:
						basecpy(base, base_f);
						break;

					case Double:
						basecpy(base, base_23);
						score++;
						break;

					case Triple:
						basecpy(base, base_3);
						score = score + 2;
						break;

					case HR:
						score = score + 3;
						break;

					case BB:
						basecpy(base, base_f);
					}
				}
				else if (cmp(base, base_13) == 0) {
					switch (batter) {
					case Out:
						outcount = outcount++;
						break;

					case Hit:
						basecpy(base, base_12);
						score++;
						break;

					case Double:
						basecpy(base, base_23);
						score++;
						break;

					case Triple:
						basecpy(base, base_3);
						score = score + 2;
						break;

					case HR:
						score = score + 3;
						break;

					case BB:
						basecpy(base, base_f);
					}
				}
				else if (cmp(base, base_23) == 0) {
					switch (batter) {
					case Out:
						outcount = outcount++;
						break;

					case Hit:
						basecpy(base, base_13);
						score++;
						break;

					case Double:
						basecpy(base, base_2);
						score = score + 2;
						break;

					case Triple:
						basecpy(base, base_3);
						score = score + 2;
						break;

					case HR:
						score = score + 3;
						break;

					case BB:
						basecpy(base, base_f);
					}
				}
				else if (cmp(base, base_f) == 0) {
					switch (batter) {
					case Out:
						outcount = outcount++;
						break;

					case Hit:
						basecpy(base, base_f);
						score++;
						break;

					case Double:
						basecpy(base, base_23);
						score = score + 2;
						break;

					case Triple:
						basecpy(base, base_3);
						score = score + 3;
						break;

					case HR:
						score = score + 4;
						break;

					case BB:
						basecpy(base, base_f);
						score++;
					}
				}
			}
			scoreboard[0][i] = score;

			outcount = 0;
			base[0] = 0;
			base[1] = 0;
			base[2] = 0;
			base[3] = 0;
			batter = 0;
			score = 0;

			while (outcount < 3) {
				batter = �Ե�08();
				if (cmp(base, base_0) == 0) {
					switch (batter) {
					case Out:
						outcount = outcount++;
						break;

					case Hit:
						basecpy(base, base_1);
						break;

					case Double:
						basecpy(base, base_2);
						break;

					case Triple:
						basecpy(base, base_3);
						break;

					case HR:
						score++;
						break;

					case BB:
						basecpy(base, base_1);
					}
				}
				else if (cmp(base, base_1) == 0) {
					switch (batter) {
					case Out:
						outcount = outcount++;
						break;

					case Hit:
						basecpy(base, base_12);
						break;

					case Double:
						basecpy(base, base_23);
						break;

					case Triple:
						basecpy(base, base_3);
						score++;
						break;

					case HR:
						score = score + 2;
						break;

					case BB:
						basecpy(base, base_12);
					}
				}
				else if (cmp(base, base_2) == 0) {
					switch (batter) {
					case Out:
						outcount = outcount++;
						break;

					case Hit:
						basecpy(base, base_13);
						break;

					case Double:
						basecpy(base, base_2);
						score++;
						break;

					case Triple:
						basecpy(base, base_2);
						score++;
						break;

					case HR:
						score = score + 2;
						break;

					case BB:
						basecpy(base, base_12);
					}
				}
				else if (cmp(base, base_3) == 0) {
					switch (batter) {
					case Out:
						outcount = outcount++;
						break;

					case Hit:
						basecpy(base, base_1);
						score++;
						break;

					case Double:
						basecpy(base, base_2);
						score++;
						break;

					case Triple:
						basecpy(base, base_3);
						score++;
						break;

					case HR:
						score = score + 2;
						break;

					case BB:
						basecpy(base, base_13);
					}
				}
				else if (cmp(base, base_12) == 0) {
					switch (batter) {
					case Out:
						outcount = outcount++;
						break;

					case Hit:
						basecpy(base, base_f);
						break;

					case Double:
						basecpy(base, base_23);
						score++;
						break;

					case Triple:
						basecpy(base, base_3);
						score = score + 2;
						break;

					case HR:
						score = score + 3;
						break;

					case BB:
						basecpy(base, base_f);
					}
				}

				else if (cmp(base, base_13) == 0) {
					switch (batter) {
					case Out:
						outcount = outcount++;
						break;

					case Hit:
						basecpy(base, base_12);
						score++;
						break;

					case Double:
						basecpy(base, base_23);
						score++;
						break;

					case Triple:
						basecpy(base, base_3);
						score = score + 2;
						break;

					case HR:
						score = score + 3;
						break;

					case BB:
						basecpy(base, base_f);
					}
				}

				else if (cmp(base, base_23) == 0) {
					switch (batter) {
					case Out:
						outcount = outcount++;
						break;

					case Hit:
						basecpy(base, base_13);
						score++;
						break;

					case Double:
						basecpy(base, base_2);
						score = score + 2;
						break;

					case Triple:
						basecpy(base, base_3);
						score = score + 2;
						break;

					case HR:
						score = score + 3;
						break;

					case BB:
						basecpy(base, base_f);
					}
				}

				else if (cmp(base, base_f) == 0) {
					switch (batter) {
					case Out:
						outcount = outcount++;
						break;

					case Hit:
						basecpy(base, base_f);
						score++;
						break;

					case Double:
						basecpy(base, base_23);
						score = score + 2;
						break;

					case Triple:
						basecpy(base, base_3);
						score = score + 3;
						break;

					case HR:
						score = score + 4;
						break;

					case BB:
						basecpy(base, base_f);
						score++;
					}
				}
				
			}
			scoreboard[1][i] = score;
		}

		for (int i = 0; i < 9; i++) {
			total1 = total1 + scoreboard[0][i];
		}
		scoreboard[0][9] = total1;

		for (int i = 0; i < 9; i++) {
			total2 = total2 + scoreboard[1][i];
		}
		scoreboard[1][9] = total2;

		printf("08SK  ");
		for (int i = 0; i < 10; i++) {
			printf("%4d ", scoreboard[0][i]);
		}
		printf("\n");
		printf("08�Ե�");
		for (int i = 0; i < 10; i++) {
			printf("%4d ", scoreboard[1][i]);
		}
		printf("\n\n");

		if (total1 > total2) {
			win1++;
			lose2++;
		}
		else if (total1 < total2) {
			win2++;
			lose1++;
		}
		else if (total1 = total2) {
			draw++;
		}
	}
	printf("08SK : %d�� %d�� %d ��\n", win1, draw, lose1);
	printf("08�Ե� : %d�� %d�� %d ��\n", win2, draw, lose2);
}